# OniProfiler powered by spark: start here

This package combines all three planned release stages into 1.0.0-rc.1.

- `OniProfiler/` is the complete project source to put at the root of your own repository. Keep its hidden `.github` directory.
- `Packages/` contains the already-built Python wheel for the dashboard, outbound agent, administrator CLI and startup wrapper. It is not the Minecraft native plugin.
- `OniProfiler-Report-Viewer.html` is the separate offline viewer.
- `Previews/` contains screenshots with explicitly synthetic demonstration data.

## Obtain the native plugin

Open `OniProfiler/docs/BUILD.md`. Publish the source, run **Build OniProfiler** in GitHub Actions, and wait for both native jobs to pass. The resulting Linux file is `endstone_oniprofiler.so`; the Windows file is `endstone_oniprofiler.dll`.

No native binary is included: the local build environment could not fetch native dependencies. The complete workflow and BDS staging tests have not run. Read `OniProfiler/VALIDATION.md` before deploying.

## Run the dashboard

Open `OniProfiler/docs/DASHBOARD.md`. Use the supplied Docker Compose configuration or install the wheel into a Python 3.11+ virtual environment. Bootstrap an administrator locally, enroll each server, and protect the deployment with HTTPS. Remote plugin controls remain locally disabled until the owner enables them.

Opt-in callback integrations are in `OniProfiler/integrations/README.md`. Exact per-entity cost and automatic whole-interpreter coverage are not claimed.
